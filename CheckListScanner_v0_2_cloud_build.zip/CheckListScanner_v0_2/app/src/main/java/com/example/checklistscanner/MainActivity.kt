package com.example.checklistscanner

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class UnitProfile(
    val id: String,
    val title: String,
    val model: String = "",
    val capacityMw: Double? = null
)

data class ParameterRule(
    val id: String,
    val unitId: String,
    val checklistType: Int,
    val name: String,
    val reference: Double,
    val low: Double,
    val high: Double,
    val unit: String,
    val warnIfEmpty: Boolean
)

data class Reading(
    val parameterId: String,
    val value: Double?,
    val rawText: String,
    val confidence: Double,
    val timestamp: Long
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CheckListApp() }
    }
}

@Composable
fun CheckListApp() {
    var selectedUnit by remember { mutableStateOf<UnitProfile?>(null) }
    var screen by remember { mutableStateOf("home") }

    val units = remember {
        mutableStateListOf(
            UnitProfile("unit-1", "واحد شماره ۱"),
            UnitProfile("unit-2", "واحد شماره ۲")
        )
    }

    MaterialTheme {
        Surface(Modifier.fillMaxSize()) {
            when (screen) {
                "home" -> HomeScreen(
                    units = units,
                    selectedUnit = selectedUnit,
                    onUnit = { selectedUnit = it },
                    onScan = { screen = "scan" },
                    onSettings = { screen = "settings" },
                    onHistory = { screen = "history" }
                )
                "scan" -> ScanScreen(
                    selectedUnit = selectedUnit,
                    onBack = { screen = "home" }
                )
                "settings" -> SettingsScreen(
                    selectedUnit = selectedUnit,
                    onBack = { screen = "home" }
                )
                "history" -> HistoryScreen(
                    selectedUnit = selectedUnit,
                    onBack = { screen = "home" }
                )
            }
        }
    }
}

@Composable
fun HomeScreen(
    units: List<UnitProfile>,
    selectedUnit: UnitProfile?,
    onUnit: (UnitProfile) -> Unit,
    onScan: () -> Unit,
    onSettings: () -> Unit,
    onHistory: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("بازرس چک‌لیست نیروگاه", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(18.dp))
        Text("واحد فعال: ${selectedUnit?.title ?: "انتخاب نشده"}")
        Spacer(Modifier.height(10.dp))
        units.forEach { unit ->
            OutlinedButton(
                onClick = { onUnit(unit) },
                modifier = Modifier.fillMaxWidth()
            ) { Text(unit.title) }
        }
        Spacer(Modifier.height(18.dp))
        Button(
            enabled = selectedUnit != null,
            onClick = onScan,
            modifier = Modifier.fillMaxWidth()
        ) { Text("📷 اسکن چک‌لیست") }
        OutlinedButton(
            enabled = selectedUnit != null,
            onClick = onHistory,
            modifier = Modifier.fillMaxWidth()
        ) { Text("📊 سوابق و نمودارها") }
        OutlinedButton(
            enabled = selectedUnit != null,
            onClick = onSettings,
            modifier = Modifier.fillMaxWidth()
        ) { Text("⚙️ تنظیمات واحد و رنج‌ها") }
    }
}

@Composable
fun ScanScreen(selectedUnit: UnitProfile?, onBack: () -> Unit) {
    var checklistType by remember { mutableIntStateOf(1) }
    var ocrText by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("برای شروع، نوع فرم را انتخاب کنید.") }

    val permission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        message = if (granted) "مجوز دوربین داده شد؛ مرحله بعد اتصال دوربین و OCR است." else "مجوز دوربین داده نشد."
    }

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("اسکن برای ${selectedUnit?.title ?: "-"}", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(12.dp))
        Row {
            FilterChip(
                selected = checklistType == 1,
                onClick = { checklistType = 1 },
                label = { Text("نوع ۱") }
            )
            Spacer(Modifier.width(8.dp))
            FilterChip(
                selected = checklistType == 2,
                onClick = { checklistType = 2 },
                label = { Text("نوع ۲") }
            )
        }
        Spacer(Modifier.height(16.dp))
        Button(onClick = {
            if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
                permission.launch(Manifest.permission.CAMERA)
            else message = "دوربین آماده است. در نسخه بعدی نواحی ثابت فرم به‌صورت خودکار خوانده می‌شوند."
        }) { Text("گرفتن عکس") }

        Spacer(Modifier.height(16.dp))
        Text(message)
        if (ocrText.isNotBlank()) Text(ocrText)

        Spacer(Modifier.weight(1f))
        OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("بازگشت") }
    }
}

@Composable
fun SettingsScreen(selectedUnit: UnitProfile?, onBack: () -> Unit) {
    var reference by remember { mutableStateOf("100") }
    var percent by remember { mutableStateOf("10") }
    var warnEmpty by remember { mutableStateOf(true) }

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("تنظیمات ${selectedUnit?.title ?: "-"}", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(14.dp))
        Text("هر واحد تنظیمات مستقل دارد و با واحدهای دیگر مخلوط نمی‌شود.")
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(reference, { reference = it }, label = { Text("مقدار مرجع") })
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(percent, { percent = it }, label = { Text("تلورانس پیش‌فرض (%)") })
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(warnEmpty, { warnEmpty = it })
            Text("اگر مقدار ثبت نشده بود هشدار بده")
        }
        Spacer(Modifier.height(8.dp))
        Text("حدود پیش‌فرض: ${reference.toDoubleOrNull()?.let { r -> r * (1 - (percent.toDoubleOrNull() ?: 10.0)/100) } ?: "-"} تا ${reference.toDoubleOrNull()?.let { r -> r * (1 + (percent.toDoubleOrNull() ?: 10.0)/100) } ?: "-"}")
        Spacer(Modifier.weight(1f))
        OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("بازگشت") }
    }
}

@Composable
fun HistoryScreen(selectedUnit: UnitProfile?, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("سوابق ${selectedUnit?.title ?: "-"}", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(12.dp))
        Text("در نسخه عملیاتی، مقادیر این واحد به‌صورت مستقل ذخیره می‌شوند و نمودار هر پارامتر با حد پایین/بالا نمایش داده خواهد شد.")
        Spacer(Modifier.height(16.dp))
        OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("بازگشت") }
    }
}
